package com.ssafy.bms;

public class RecordNotFoundException extends Exception {

}
