package com.ssafy.bms;

public class DuplicateException extends Exception {

//	super("중복입니다");
}
