package 순열;

public class 백준_바이러스 {

	
	public static void main(String[] args) {
		

	}

}
