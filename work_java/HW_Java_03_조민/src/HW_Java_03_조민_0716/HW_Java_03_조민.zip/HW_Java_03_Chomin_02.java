package HW_Java_03_����;

import java.util.Scanner;

public class HW_Java_03_Chomin_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int input1 = sc.nextInt();
		int input2 = sc.nextInt();
		
		int mul = input1 * input2;
		int div = input1 / input2;
		
		System.out.println("��=" + mul);
		System.out.println("��=" + div);
		
		
	}

}
