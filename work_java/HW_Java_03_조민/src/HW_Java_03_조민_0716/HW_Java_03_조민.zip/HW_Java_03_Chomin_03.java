package HW_Java_03_����;

import java.util.Scanner;

public class HW_Java_03_Chomin_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int weight = sc.nextInt();
		int width = sc.nextInt();
		
		int biman = width + 100 - weight;
		
		System.out.printf("�񸸼�ġ�� %d�Դϴ�.", biman);
		System.out.println();
		System.out.print("����� ���̱���");
	}

}
