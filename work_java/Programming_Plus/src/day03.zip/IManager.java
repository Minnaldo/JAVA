package day03;

public interface IManager {
	
	public int add(Employee emp);
	
	
	public int modify(Employee emp);
	
	
	public int delete(Employee emp);
	
	public Employee[] search_all();
	
	public Employee search(int num);
	
	public void allWork();
}
