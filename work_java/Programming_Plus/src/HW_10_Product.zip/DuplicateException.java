package HW_10_Product;

public class DuplicateException extends Exception {
	public DuplicateException() {
		System.out.println("중복되었어!");
	}

}
