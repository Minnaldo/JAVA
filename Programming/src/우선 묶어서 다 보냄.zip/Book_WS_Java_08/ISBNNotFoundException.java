package Book_WS_Java_08;

public class ISBNNotFoundException {
	String errmsg = "ISBNNotFoundException errmsg.";
	
	public ISBNNotFoundException()
	{
		
	}
	
	public String showError()
	{
		return errmsg;
	}
}
