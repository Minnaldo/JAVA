package Book_WS_Java_08;

public class BookTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
