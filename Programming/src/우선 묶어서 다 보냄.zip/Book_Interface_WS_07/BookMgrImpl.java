package Book_Interface_WS_07;

public class BookMgrImpl implements IBookMgr
{
	private Book[] books = new Book[100];
//	private int max = 10;
	private int index = 0;

	
	
}
