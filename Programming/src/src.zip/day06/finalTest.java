package day06;

//final
//위치
//class : 상속안돼
//method = Override	안돼
//variable : 상수  (값 안 바뀜.)

/*final 뭐라는지 수업 못들음.*/

//class Method variable
public class finalTest {
	final int a = 100;
	
	void change()
	{
		a = 70;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
