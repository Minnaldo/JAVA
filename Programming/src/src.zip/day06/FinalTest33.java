package day06;

public class FinalTest33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Integer in = new Integer("3");
		int a;
//		a =in.intValue();
		a = in;
		
		
		//자바 5.0부터는
		in = a;
	}

}
