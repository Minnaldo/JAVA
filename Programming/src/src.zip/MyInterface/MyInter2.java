package MyInterface;

public interface MyInter2 {
	void disable();
}
