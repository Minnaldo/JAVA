package MyInterface;

//인터페이스는 Extends 가 아닌  implements로 받는다.
//상속이라네.. 뭔소리냐?  implements로 받아도 상속이라는데
public class MySub extends Object implements MyInter, MyInter2{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disable() {
		// TODO Auto-generated method stub
		
	}

}
