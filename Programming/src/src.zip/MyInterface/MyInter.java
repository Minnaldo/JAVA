package MyInterface;

public interface MyInter {
	
	public final int i = 10;
		
	//void show()만 해도 컴파일 시
	//public abstract가 붙는다.
	
	abstract void show();
	
	//구현부를 가질 수 없다.
//	abstract void show();
	
}
