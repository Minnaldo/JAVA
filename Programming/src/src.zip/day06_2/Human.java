package day06_2;

public class Human extends Animal {
	
	@Override
	public void walk() {
		// TODO Auto-generated method stub
		System.out.println("사람이 걸어요");
	}

}
