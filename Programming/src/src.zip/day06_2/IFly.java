package day06_2;

public interface IFly {
	//인터페이스는 그냥 선언하면 자동으로 public final 추가!!!
	//인터페이스는 바디 추가하면 Error!!!
	void fly();
}
