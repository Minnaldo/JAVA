package day06_2;


public class Lion extends Animal {

	@Override
	public void walk() {
		// TODO Auto-generated method stub
		System.out.println("사자가 걸어요");
	}

	public void roar()
	{
		System.out.println("사자가 으르렁 거린다.");
	}
}
