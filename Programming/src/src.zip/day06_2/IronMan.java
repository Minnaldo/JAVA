package day06_2;

public class IronMan extends Human implements IFly, IRazer {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attack() {
		// TODO Auto-generated method stub
		
	}

}
