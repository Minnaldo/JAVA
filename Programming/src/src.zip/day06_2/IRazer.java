package day06_2;

public interface IRazer {
	void attack();
}
