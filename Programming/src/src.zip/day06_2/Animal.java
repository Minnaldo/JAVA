package day06_2;

//Animal 이 객체화 되면 안 돼.
public abstract class Animal {
	public String whoamI()
	{
		return "동물";
	}
	
	
	public abstract void walk();


}
