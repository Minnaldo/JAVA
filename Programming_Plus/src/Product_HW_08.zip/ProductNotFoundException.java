package GGGG;

public class ProductNotFoundException extends Exception {
	public ProductNotFoundException() {
		System.out.println("없어 상품이");
	}
}
