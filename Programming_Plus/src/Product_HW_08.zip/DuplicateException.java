package GGGG;

public class DuplicateException extends Exception {
	public DuplicateException() {
		System.out.println("중복되었어!");
	}

}
