package GGGG;

public class TV extends Product{
	private int inch;
	private String type;
	
	public TV(String productNum, String name, int price, int amount, int inch, String type) {
		super(productNum, name, price, amount);
		this.inch = inch;
		this.type = type;
	}

	public int getInch() {
		return inch;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	
	@Override
	public String toString() {
		return "TV [inch=" + inch + ", type=" + type + ", getProductNum()=" + getProductNum() + ", getName()="
				+ getName() + ", getPrice()=" + getPrice() + ", getAmount()=" + getAmount() + "]";
	}

	



	
}
